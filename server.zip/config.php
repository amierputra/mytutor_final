<?php
$servername = 'localhost';
$username   = 'amierputra_mytutoradmin';
$password   = '3$z*NE2U@XZA';
$dbname     = 'amierputra_mytutor';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>